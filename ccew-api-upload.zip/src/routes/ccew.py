import os
import json
import requests
from datetime import datetime
from flask import Blueprint, request, jsonify, send_file
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.units import inch
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import io

ccew_bp = Blueprint('ccew', __name__)

# Create uploads directory if it doesn't exist
UPLOADS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'uploads')
os.makedirs(UPLOADS_DIR, exist_ok=True)

def generate_ccew_pdf(form_data):
    """Generate comprehensive PDF from CCEW form data"""
    try:
        # Create PDF buffer
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
        
        # Container for the 'Flowable' objects
        elements = []
        
        # Define styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            spaceAfter=30,
            textColor=colors.red,
            alignment=1  # Center alignment
        )
        
        section_style = ParagraphStyle(
            'SectionHeader',
            parent=styles['Heading2'],
            fontSize=12,
            spaceAfter=12,
            textColor=colors.black,
            backColor=colors.lightgrey,
            borderPadding=6
        )
        
        normal_style = styles['Normal']
        
        # Title
        title = Paragraph("NSW Fair Trading<br/>Online Certificate Compliance Electrical Work (CCEW)", title_style)
        elements.append(title)
        elements.append(Spacer(1, 12))
        
        # Serial Number
        serial_info = Paragraph(f"<b>Serial No:</b> {form_data.get('serialNo', 'N/A')}", normal_style)
        elements.append(serial_info)
        elements.append(Spacer(1, 20))
        
        # Installation Address Section
        elements.append(Paragraph("INSTALLATION ADDRESS", section_style))
        
        installation_data = [
            ['Property Name', form_data.get('propertyName', 'N/A')],
            ['Address', f"{form_data.get('streetNumber', '')} {form_data.get('streetName', '')}".strip() or 'N/A'],
            ['Suburb', form_data.get('suburb', 'N/A')],
            ['State', form_data.get('state', 'NSW')],
            ['Post Code', form_data.get('postCode', 'N/A')],
            ['Pit/Pillar/Pole No.', form_data.get('pitPillarPoleNumber', 'N/A')],
            ['NMI', form_data.get('nmi', 'N/A')],
            ['Meter No.', form_data.get('meterNumber', 'N/A')],
            ['AEMO Metering Provider ID', form_data.get('aemoMeteringProviderId', 'N/A')]
        ]
        
        installation_table = Table(installation_data, colWidths=[2*inch, 3*inch])
        installation_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(installation_table)
        elements.append(Spacer(1, 20))
        
        # Customer Details Section
        elements.append(Paragraph("CUSTOMER DETAILS", section_style))
        
        customer_name = f"{form_data.get('customerFirstName', '')} {form_data.get('customerLastName', '')}".strip()
        customer_address = f"{form_data.get('customerStreetNumber', '')} {form_data.get('customerStreetName', '')}".strip()
        
        customer_data = [
            ['Customer Name', customer_name or 'N/A'],
            ['Company', form_data.get('customerCompanyName', 'N/A')],
            ['Address', customer_address or 'N/A'],
            ['Suburb', form_data.get('customerSuburb', 'N/A')],
            ['State', form_data.get('customerState', 'NSW')],
            ['Post Code', form_data.get('customerPostCode', 'N/A')],
            ['Email', form_data.get('customerEmail', 'N/A')],
            ['Office No.', form_data.get('customerOfficeNo', 'N/A')],
            ['Mobile No.', form_data.get('customerMobileNo', 'N/A')]
        ]
        
        customer_table = Table(customer_data, colWidths=[2*inch, 3*inch])
        customer_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(customer_table)
        elements.append(Spacer(1, 20))
        
        # Installation Details Section
        elements.append(Paragraph("INSTALLATION DETAILS", section_style))
        
        work_carried_out = ', '.join(form_data.get('workCarriedOut', [])) if form_data.get('workCarriedOut') else 'N/A'
        special_conditions = ', '.join(form_data.get('specialConditions', [])) if form_data.get('specialConditions') else 'None'
        
        installation_details_data = [
            ['Type of Installation', form_data.get('installationType', 'N/A')],
            ['Work Carried Out', work_carried_out],
            ['Special Conditions', special_conditions]
        ]
        
        if form_data.get('nonComplianceNo'):
            installation_details_data.append(['Non-Compliance No.', form_data.get('nonComplianceNo')])
        
        installation_details_table = Table(installation_details_data, colWidths=[2*inch, 3*inch])
        installation_details_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(installation_details_table)
        elements.append(Spacer(1, 20))
        
        # Equipment Details Section
        elements.append(Paragraph("EQUIPMENT DETAILS", section_style))
        
        equipment_data = []
        if form_data.get('equipment'):
            for key, equipment in form_data['equipment'].items():
                if equipment.get('selected'):
                    equipment_name = 'Socket Outlets' if key == 'socketOutlets' else key.title()
                    details = []
                    if equipment.get('rating'):
                        details.append(f"Rating: {equipment['rating']}")
                    if equipment.get('numberInstalled'):
                        details.append(f"Number: {equipment['numberInstalled']}")
                    if equipment.get('particulars'):
                        details.append(f"Particulars: {equipment['particulars']}")
                    
                    equipment_data.append([equipment_name, ', '.join(details) if details else 'Selected'])
        
        if not equipment_data:
            equipment_data = [['No equipment selected', 'N/A']]
        
        equipment_table = Table(equipment_data, colWidths=[2*inch, 3*inch])
        equipment_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(equipment_table)
        elements.append(Spacer(1, 20))
        
        # Meters Section
        elements.append(Paragraph("METERS", section_style))
        
        meters_data = []
        if form_data.get('meters'):
            for i, meter in enumerate(form_data['meters']):
                status = []
                if meter.get('i'): status.append('I (Installed)')
                if meter.get('r'): status.append('R (Removed)')
                if meter.get('e'): status.append('E (Existing)')
                
                if status:
                    meter_info = f"Meter {i+1}: {meter.get('meterNo', 'N/A')} - {', '.join(status)}"
                    meters_data.append([meter_info, ''])
                    
                    if meter.get('dials'):
                        meters_data.append(['  No. Dials', meter['dials']])
                    if meter.get('reading'):
                        meters_data.append(['  Reading', meter['reading']])
                    if meter.get('tariff'):
                        meters_data.append(['  Tariff', meter['tariff']])
        
        meters_data.extend([
            ['Load Within Capacity', form_data.get('loadWithinCapacity', 'N/A')],
            ['Work Connected to Supply', form_data.get('workConnectedToSupply', 'N/A')]
        ])
        
        if form_data.get('estimatedLoadIncrease'):
            meters_data.append(['Estimated Load Increase', form_data['estimatedLoadIncrease']])
        
        meters_table = Table(meters_data, colWidths=[2*inch, 3*inch])
        meters_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(meters_table)
        elements.append(Spacer(1, 20))
        
        # Installer License Details Section
        elements.append(Paragraph("INSTALLER LICENSE DETAILS", section_style))
        
        installer_name = f"{form_data.get('installerFirstName', '')} {form_data.get('installerLastName', '')}".strip()
        installer_address = f"{form_data.get('installerStreetNumber', '')} {form_data.get('installerStreetName', '')}".strip()
        
        installer_data = [
            ['Name', installer_name or 'N/A'],
            ['Address', installer_address or 'N/A'],
            ['Suburb', f"{form_data.get('installerSuburb', '')}, {form_data.get('installerState', 'NSW')} {form_data.get('installerPostCode', '')}"],
            ['Email', form_data.get('installerEmail', 'N/A')],
            ['Office No.', form_data.get('installerOfficeNo', 'N/A')],
            ['Contractor License No.', form_data.get('contractorLicenseNo', 'N/A')],
            ['Contractor Expiry Date', form_data.get('contractorExpiryDate', 'N/A')]
        ]
        
        installer_table = Table(installer_data, colWidths=[2*inch, 3*inch])
        installer_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(installer_table)
        elements.append(Spacer(1, 20))
        
        # Test Report Section
        elements.append(Paragraph("TEST REPORT", section_style))
        
        tests_completed = ', '.join(form_data.get('testReport', [])) if form_data.get('testReport') else 'N/A'
        
        test_data = [
            ['Tests Completed', tests_completed],
            ['Test Completion Date', form_data.get('testCompletedDate', 'N/A')]
        ]
        
        test_table = Table(test_data, colWidths=[2*inch, 3*inch])
        test_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(test_table)
        elements.append(Spacer(1, 20))
        
        # Tester License Details Section
        elements.append(Paragraph("TESTER LICENSE DETAILS", section_style))
        
        tester_name = f"{form_data.get('testerFirstName', '')} {form_data.get('testerLastName', '')}".strip()
        tester_address = f"{form_data.get('testerStreetNumber', '')} {form_data.get('testerStreetName', '')}".strip()
        
        tester_data = [
            ['Name', tester_name or 'N/A'],
            ['Address', tester_address or 'N/A'],
            ['Suburb', f"{form_data.get('testerSuburb', '')}, {form_data.get('testerState', 'NSW')} {form_data.get('testerPostCode', '')}"],
            ['Email', form_data.get('testerEmail', 'N/A')],
            ['Office No.', form_data.get('testerOfficeNo', 'N/A')],
            ['Contractor License No.', form_data.get('testerContractorLicenseNo', 'N/A')],
            ['Contractor Expiry Date', form_data.get('testerContractorExpiryDate', 'N/A')]
        ]
        
        tester_table = Table(tester_data, colWidths=[2*inch, 3*inch])
        tester_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(tester_table)
        elements.append(Spacer(1, 20))
        
        # Submission Details Section
        elements.append(Paragraph("SUBMISSION DETAILS", section_style))
        
        submission_data = [
            ['Energy Provider', form_data.get('energyProvider', 'N/A')],
            ['Meter Provider Email', form_data.get('meterProviderEmail', 'N/A')],
            ['Owner Email', form_data.get('ownerEmail', 'N/A')],
            ['Submission Date', datetime.now().strftime('%d/%m/%Y')],
            ['Submission Time', datetime.now().strftime('%H:%M:%S')]
        ]
        
        submission_table = Table(submission_data, colWidths=[2*inch, 3*inch])
        submission_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(submission_table)
        elements.append(Spacer(1, 20))
        
        # Certification Statement
        elements.append(Paragraph("CERTIFICATION", section_style))
        cert_text = Paragraph("I certify that the information provided in this Certificate Compliance Electrical Work (CCEW) is true and correct.", normal_style)
        elements.append(cert_text)
        elements.append(Spacer(1, 12))
        
        # Electronic submission note
        ref_text = Paragraph(f"Electronically submitted via automated system<br/>Reference: CCEW-{form_data.get('serialNo', 'Unknown')}-{int(datetime.now().timestamp())}", 
                           ParagraphStyle('Reference', parent=normal_style, fontSize=8, textColor=colors.grey))
        elements.append(ref_text)
        
        # Build PDF
        doc.build(elements)
        
        # Get PDF data
        pdf_data = buffer.getvalue()
        buffer.close()
        
        return pdf_data
        
    except Exception as e:
        print(f"Error generating PDF: {e}")
        raise e

def send_ccew_email(form_data, pdf_data, filename):
    """Send comprehensive email with PDF attachment"""
    try:
        # Email configuration (using environment variables)
        smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        smtp_port = int(os.getenv('SMTP_PORT', '587'))
        sender_email = os.getenv('SENDER_EMAIL', 'admin@proformelec.com.au')
        sender_password = os.getenv('SENDER_PASSWORD', '')
        
        if not sender_password:
            print("Warning: No email password configured")
            return {
                'sent': False,
                'error': 'Email password not configured'
            }
        
        # Determine primary recipient based on energy provider
        primary_recipient = "datanorth@ausgrid.com.au" if form_data.get('energyProvider') == 'Ausgrid' else "metercrew@finance.nsw.gov.au"
        
        # Build recipient list
        recipients = [primary_recipient]
        cc_recipients = []
        
        # Add meter provider and owner emails as CC
        if form_data.get('meterProviderEmail') and '@' in form_data['meterProviderEmail']:
            cc_recipients.append(form_data['meterProviderEmail'])
        if form_data.get('ownerEmail') and '@' in form_data['ownerEmail']:
            cc_recipients.append(form_data['ownerEmail'])
        
        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = ', '.join(recipients)
        if cc_recipients:
            msg['Cc'] = ', '.join(cc_recipients)
        
        customer_name = f"{form_data.get('customerFirstName', '')} {form_data.get('customerLastName', '')}".strip()
        msg['Subject'] = f"CCEW Submission - {form_data.get('serialNo', 'Job')} - {customer_name} - {form_data.get('energyProvider', 'Provider')}"
        
        # Email body
        installation_address = ', '.join(filter(None, [
            form_data.get('streetNumber'),
            form_data.get('streetName'),
            form_data.get('suburb'),
            form_data.get('state', 'NSW'),
            form_data.get('postCode')
        ]))
        
        work_carried_out = ', '.join(form_data.get('workCarriedOut', [])) if form_data.get('workCarriedOut') else 'N/A'
        
        selected_equipment = []
        if form_data.get('equipment'):
            for key, eq in form_data['equipment'].items():
                if eq.get('selected'):
                    equipment_name = 'Socket Outlets' if key == 'socketOutlets' else key.title()
                    selected_equipment.append(equipment_name)
        
        equipment_list = ', '.join(selected_equipment) if selected_equipment else 'N/A'
        tests_completed = ', '.join(form_data.get('testReport', [])) if form_data.get('testReport') else 'N/A'
        
        installer_name = f"{form_data.get('installerFirstName', '')} {form_data.get('installerLastName', '')}".strip()
        tester_name = f"{form_data.get('testerFirstName', '')} {form_data.get('testerLastName', '')}".strip()
        
        body = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .header {{ background: #dc2626; color: white; padding: 20px; text-align: center; }}
        .content {{ padding: 20px; }}
        .info-box {{ background: #f3f4f6; padding: 15px; border-left: 4px solid #dc2626; margin: 15px 0; }}
        .info-table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
        .info-table th, .info-table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        .info-table th {{ background: #f3f4f6; }}
        .footer {{ background: #f9fafb; padding: 15px; text-align: center; font-size: 12px; color: #666; }}
    </style>
</head>
<body>
    <div class='header'>
        <h1>NSW Fair Trading</h1>
        <h2>Certificate Compliance Electrical Work (CCEW) Submission</h2>
    </div>
    
    <div class='content'>
        <div class='info-box'>
            <h3>📋 Job Information</h3>
            <p>
                <strong>Serial No (Job Number):</strong> {form_data.get('serialNo', 'N/A')}<br>
                <strong>Property Name:</strong> {form_data.get('propertyName', 'N/A')}<br>
                <strong>Installation Address:</strong> {installation_address}<br>
                <strong>NMI:</strong> {form_data.get('nmi', 'N/A')}<br>
                <strong>Energy Provider:</strong> {form_data.get('energyProvider', 'N/A')}
            </p>
        </div>
        
        <h3>Customer Details</h3>
        <table class='info-table'>
            <tr><td><strong>Customer Name</strong></td><td>{customer_name}</td></tr>
            <tr><td><strong>Company</strong></td><td>{form_data.get('customerCompanyName', 'N/A')}</td></tr>
            <tr><td><strong>Email</strong></td><td>{form_data.get('customerEmail', 'N/A')}</td></tr>
            <tr><td><strong>Mobile</strong></td><td>{form_data.get('customerMobileNo', 'N/A')}</td></tr>
        </table>
        
        <h3>Installation Details</h3>
        <table class='info-table'>
            <tr><td><strong>Installation Type</strong></td><td>{form_data.get('installationType', 'N/A')}</td></tr>
            <tr><td><strong>Work Carried Out</strong></td><td>{work_carried_out}</td></tr>
            <tr><td><strong>Equipment Installed</strong></td><td>{equipment_list}</td></tr>
            <tr><td><strong>Load Within Capacity</strong></td><td>{form_data.get('loadWithinCapacity', 'N/A')}</td></tr>
            <tr><td><strong>Work Connected to Supply</strong></td><td>{form_data.get('workConnectedToSupply', 'N/A')}</td></tr>
        </table>
        
        <h3>License Details</h3>
        <table class='info-table'>
            <tr><td><strong>Installer</strong></td><td>{installer_name}</td></tr>
            <tr><td><strong>Installer License</strong></td><td>{form_data.get('contractorLicenseNo', 'N/A')}</td></tr>
            <tr><td><strong>Tester</strong></td><td>{tester_name}</td></tr>
            <tr><td><strong>Tester License</strong></td><td>{form_data.get('testerContractorLicenseNo', 'N/A')}</td></tr>
        </table>
        
        <h3>Test Report</h3>
        <table class='info-table'>
            <tr><td><strong>Tests Completed</strong></td><td>{tests_completed}</td></tr>
            <tr><td><strong>Test Completion Date</strong></td><td>{form_data.get('testCompletedDate', 'N/A')}</td></tr>
        </table>
        
        <h3>Submission Details</h3>
        <table class='info-table'>
            <tr><td><strong>Submission Date</strong></td><td>{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</td></tr>
            <tr><td><strong>Submitted To</strong></td><td>{primary_recipient}</td></tr>
            {f"<tr><td><strong>Copies Sent To</strong></td><td>{', '.join(cc_recipients)}</td></tr>" if cc_recipients else ""}
        </table>
        
        <div class='info-box' style='background: #e5f3ff; border-left-color: #0066cc;'>
            <p style='margin: 0; color: #0066cc;'>
                <strong>This CCEW has been submitted electronically via the Proform Electrical automated system.</strong><br>
                Please find the completed CCEW form attached as a PDF document.<br>
                This submission complies with NSW Fair Trading requirements for electrical work certification.
            </p>
        </div>
    </div>
    
    <div class='footer'>
        <p>Generated by Proform Electrical CCEW Automation System<br>
        For inquiries, contact: admin@proformelec.com.au</p>
    </div>
</body>
</html>
        """
        
        msg.attach(MIMEText(body, 'html'))
        
        # Attach PDF
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(pdf_data)
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename= {filename}')
        msg.attach(part)
        
        # Send email
        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(sender_email, sender_password)
            text = msg.as_string()
            server.sendmail(sender_email, recipients + cc_recipients, text)
            server.quit()
            
            return {
                'sent': True,
                'primaryRecipient': primary_recipient,
                'ccRecipients': cc_recipients,
                'messageId': f'sent-{int(datetime.now().timestamp())}'
            }
        except Exception as e:
            print(f"Error sending email: {e}")
            return {
                'sent': False,
                'error': str(e)
            }
        
    except Exception as e:
        print(f"Error in email function: {e}")
        return {
            'sent': False,
            'error': str(e)
        }

def notify_make_webhook(form_data, filename, filepath, reference, email_result):
    """Send notification to Make.com webhook about completed CCEW submission"""
    try:
        webhook_url = os.getenv('MAKE_WEBHOOK_URL')
        if not webhook_url:
            print("Warning: No Make.com webhook URL configured")
            return False
        
        # Prepare webhook payload
        webhook_data = {
            'success': True,
            'reference': reference,
            'filename': filename,
            'filepath': filepath,
            'timestamp': datetime.now().isoformat(),
            'formData': {
                'serialNo': form_data.get('serialNo'),
                'customerFirstName': form_data.get('customerFirstName'),
                'customerLastName': form_data.get('customerLastName'),
                'customerCompanyName': form_data.get('customerCompanyName'),
                'customerEmail': form_data.get('customerEmail'),
                'energyProvider': form_data.get('energyProvider'),
                'installationType': form_data.get('installationType'),
                'testCompletedDate': form_data.get('testCompletedDate'),
                'meterProviderEmail': form_data.get('meterProviderEmail'),
                'ownerEmail': form_data.get('ownerEmail')
            },
            'email': email_result
        }
        
        # Send webhook notification
        response = requests.post(
            webhook_url,
            json=webhook_data,
            headers={'Content-Type': 'application/json'},
            timeout=30
        )
        
        if response.status_code == 200:
            print(f"Webhook notification sent successfully to Make.com")
            return True
        else:
            print(f"Webhook notification failed: {response.status_code} - {response.text}")
            return False
            
    except Exception as e:
        print(f"Error sending webhook notification: {e}")
        return False

def validate_ccew_form(form_data):
    """Comprehensive form validation"""
    errors = []
    
    # Required fields validation
    required_fields = [
        ('serialNo', 'Serial Number (Job Number)'),
        ('streetNumber', 'Street Number'),
        ('streetName', 'Street Name'),
        ('suburb', 'Suburb'),
        ('postCode', 'Post Code'),
        ('customerFirstName', 'Customer First Name'),
        ('customerLastName', 'Customer Last Name'),
        ('aemoMeteringProviderId', 'AEMO Metering Provider ID'),
        ('installationType', 'Type of Installation'),
        ('loadWithinCapacity', 'Load capacity question'),
        ('workConnectedToSupply', 'Work connection to supply question'),
        ('testCompletedDate', 'Test Completion Date'),
        ('testerFirstName', 'Tester First Name'),
        ('testerLastName', 'Tester Last Name'),
        ('testerContractorLicenseNo', 'Tester Contractor License Number'),
        ('testerContractorExpiryDate', 'Tester Contractor License Expiry Date'),
        ('energyProvider', 'Energy Provider'),
        ('certificationStatement', 'Certification statement')
    ]
    
    for field, label in required_fields:
        if not form_data.get(field):
            errors.append(f'{label} is required')
    
    # Work carried out validation
    if not form_data.get('workCarriedOut') or len(form_data['workCarriedOut']) == 0:
        errors.append('At least one Work Carried Out option must be selected')
    
    # Equipment validation
    if form_data.get('equipment'):
        has_equipment = any(eq.get('selected') for eq in form_data['equipment'].values())
        if not has_equipment:
            errors.append('At least one equipment type must be selected')
    
    # Meter validation
    if form_data.get('meters'):
        has_valid_meter = any(meter.get('i') or meter.get('r') or meter.get('e') for meter in form_data['meters'])
        if not has_valid_meter:
            errors.append('At least one meter must have I, R, or E selected')
    else:
        errors.append('At least one meter entry is required')
    
    # Test report validation
    if not form_data.get('testReport') or len(form_data['testReport']) == 0:
        errors.append('At least one test must be selected in Test Report')
    
    # Date validation
    try:
        if form_data.get('testerContractorExpiryDate'):
            expiry_date = datetime.strptime(form_data['testerContractorExpiryDate'], '%Y-%m-%d')
            if expiry_date <= datetime.now():
                errors.append('Tester Contractor License Expiry Date must be in the future')
    except ValueError:
        errors.append('Invalid date format for Tester Contractor License Expiry Date')
    
    # Email validation
    import re
    email_regex = r'^[^\s@]+@[^\s@]+\.[^\s@]+$'
    
    email_fields = [
        ('customerEmail', 'Customer Email'),
        ('meterProviderEmail', 'Meter Provider Email'),
        ('ownerEmail', 'Owner Email')
    ]
    
    for field, label in email_fields:
        email = form_data.get(field)
        if email and not re.match(email_regex, email):
            errors.append(f'{label} format is invalid')
    
    return errors

@ccew_bp.route('/submit-ccew', methods=['POST'])
def submit_ccew():
    """Handle comprehensive CCEW form submission with Make.com webhook notification"""
    try:
        form_data = request.get_json()
        
        if not form_data:
            return jsonify({
                'success': False,
                'message': 'No form data received'
            }), 400
        
        # Comprehensive validation
        validation_errors = validate_ccew_form(form_data)
        if validation_errors:
            return jsonify({
                'success': False,
                'message': 'Form validation failed',
                'errors': validation_errors
            }), 400
        
        # Generate unique reference
        timestamp = int(datetime.now().timestamp())
        reference = f"CCEW-{form_data.get('serialNo', 'Unknown')}-{timestamp}"
        
        print(f"Processing CCEW submission: {reference}")
        print(f"Customer: {form_data.get('customerFirstName')} {form_data.get('customerLastName')}")
        print(f"Energy Provider: {form_data.get('energyProvider')}")
        
        # Generate comprehensive PDF
        pdf_data = generate_ccew_pdf(form_data)
        
        # Save PDF to uploads directory
        filename = f"CCEW-{form_data.get('serialNo', 'Unknown')}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.pdf"
        filepath = os.path.join(UPLOADS_DIR, filename)
        
        with open(filepath, 'wb') as f:
            f.write(pdf_data)
        
        print(f"PDF generated and saved: {filename}")
        
        # Send comprehensive email
        email_result = send_ccew_email(form_data, pdf_data, filename)
        
        if email_result.get('sent'):
            print(f"Email sent successfully to: {email_result['primaryRecipient']}")
            if email_result.get('ccRecipients'):
                print(f"CC sent to: {', '.join(email_result['ccRecipients'])}")
        else:
            print(f"Email sending failed: {email_result.get('error', 'Unknown error')}")
        
        # Send webhook notification to Make.com
        webhook_sent = notify_make_webhook(form_data, filename, filepath, reference, email_result)
        
        if webhook_sent:
            print(f"Make.com webhook notification sent successfully")
        else:
            print(f"Make.com webhook notification failed")
        
        # Prepare comprehensive response
        response = {
            'success': True,
            'reference': reference,
            'message': 'CCEW form submitted successfully',
            'timestamp': datetime.now().isoformat(),
            'filename': filename,
            'filepath': filepath,
            'formData': {
                'serialNo': form_data.get('serialNo'),
                'customerName': f"{form_data.get('customerFirstName', '')} {form_data.get('customerLastName', '')}".strip(),
                'energyProvider': form_data.get('energyProvider'),
                'installationType': form_data.get('installationType'),
                'testCompletedDate': form_data.get('testCompletedDate')
            },
            'email': email_result,
            'webhook': {
                'sent': webhook_sent,
                'url': os.getenv('MAKE_WEBHOOK_URL', 'Not configured')
            }
        }
        
        print(f"CCEW submission completed successfully: {reference}")
        return jsonify(response)
        
    except Exception as e:
        print(f"Error processing CCEW submission: {e}")
        return jsonify({
            'success': False,
            'message': 'Internal server error occurred while processing CCEW submission',
            'error': str(e) if os.getenv('FLASK_ENV') == 'development' else 'Please contact support if this issue persists'
        }), 500

@ccew_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'OK',
        'timestamp': datetime.now().isoformat(),
        'service': 'CCEW API Server',
        'version': '2.1',
        'trigger': 'Review and finish button in SimPro',
        'webhook_configured': bool(os.getenv('MAKE_WEBHOOK_URL'))
    })

@ccew_bp.route('/submissions', methods=['GET'])
def get_submissions():
    """Get list of submitted CCEWs"""
    try:
        files = [f for f in os.listdir(UPLOADS_DIR) if f.endswith('.pdf')]
        
        submissions = []
        for file in files:
            filepath = os.path.join(UPLOADS_DIR, file)
            stat = os.stat(filepath)
            submissions.append({
                'filename': file,
                'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                'size': stat.st_size,
                'sizeFormatted': f"{stat.st_size / 1024:.1f} KB"
            })
        
        # Sort by creation date (newest first)
        submissions.sort(key=lambda x: x['created'], reverse=True)
        
        return jsonify({
            'success': True,
            'count': len(submissions),
            'submissions': submissions
        })
        
    except Exception as e:
        print(f"Error fetching submissions: {e}")
        return jsonify({
            'success': False,
            'message': 'Failed to fetch submissions'
        }), 500

@ccew_bp.route('/download/<filename>', methods=['GET'])
def download_pdf(filename):
    """Download PDF endpoint for Make.com webhook to retrieve completed CCEWs"""
    try:
        # Security check - only allow PDF files and prevent directory traversal
        if not filename.endswith('.pdf') or '..' in filename or '/' in filename:
            return jsonify({
                'success': False,
                'message': 'Invalid filename'
            }), 400
        
        filepath = os.path.join(UPLOADS_DIR, filename)
        
        # Check if file exists
        if not os.path.exists(filepath):
            return jsonify({
                'success': False,
                'message': 'File not found'
            }), 404
        
        # Send file
        return send_file(filepath, as_attachment=True, download_name=filename, mimetype='application/pdf')
        
    except Exception as e:
        print(f"Error downloading file: {e}")
        return jsonify({
            'success': False,
            'message': 'Failed to download file'
        }), 500
